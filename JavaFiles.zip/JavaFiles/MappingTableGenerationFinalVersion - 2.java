package test;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import java.io.FileWriter;
import java.io.IOException;

class Permutation {
	/*
	 * arr[] ---> Input Array data[] ---> Temporary array to store current
	 * combination start & end ---> Staring and Ending indexes in arr[] index --->
	 * Current index in data[] r ---> Size of a combination to be printed
	 */
	static void combinationUtil(Integer[] arr, int data[], int start, int end, int index, int r,
			HashMap<String, String> UseCaseMapping, HashMap<Integer, String> UseCaseCodeNumbers,
			HashMap<String, Set<String>> ExclusionMap) {

		Set<String> combinaison = new HashSet<String>();
		String[] OutputCSV = new String[r];
		int sum = 0;

		if (index == r) {
			for (int j = 0; j < r; j++)
				sum += data[j];
			for (int j = 0; j < r; j++) {
				combinaison.add(UseCaseCodeNumbers.get(data[j]));
				OutputCSV[j] = sum + "," + UseCaseMapping.get(Integer.toString(data[j]));
			}
		// Exclusion rules to be added
			boolean Excluded = false;
			for (int j = 0; j < r; j++) {
				Excluded = false;
				if (ExclusionMap.keySet().contains(UseCaseCodeNumbers.get(data[j])))
					for (String val : ExclusionMap.get(UseCaseCodeNumbers.get(data[j]))) {
						if (combinaison.contains(val)) {
							Excluded = true;
							break;
						}
					}
				if (Excluded) {
					OutputCSV[j] += ",";
				} else
					OutputCSV[j] += "," + UseCaseCodeNumbers.get(data[j]);
				System.out.println(OutputCSV[j]);
			}
			System.out.println("------------------------------------------------");
			generateCSV(OutputCSV);

			return;
		}

		// replace index with all possible elements. The condition
		// "end-i+1 >= r-index" makes sure that including one element
		// at index will make a combination with remaining elements
		// at remaining positions
		for (int i = start; i <= end && end - i + 1 >= r - index; i++) {
			data[index] = arr[i];
			combinationUtil(arr, data, i + 1, end, index + 1, r, UseCaseMapping, UseCaseCodeNumbers, ExclusionMap);
		}
	}

	// The main function that prints all combinations of size r
	// in arr[] of size n. This function mainly uses combinationUtil()
	static void printCombination(Integer[] intarray, int n, int r, HashMap<String, String> UseCaseMapping,
			HashMap<Integer, String> UseCaseCodeNumbers, HashMap<String, Set<String>> ExclusionMap) {
		// A temporary array to store all combination one by one
		int data[] = new int[r];
		// Print all combination using temprary array 'data[]'
		combinationUtil(intarray, data, 0, n - 1, 0, r, UseCaseMapping, UseCaseCodeNumbers, ExclusionMap);
	}

	/* Driver function to check for above function */
	public static void main(String[] args) {
		HashMap<String, String> UseCaseMapping = new HashMap<String, String>();
		HashMap<Integer, String> UseCaseCodeNumbers = new HashMap<Integer, String>();
		HashMap<String, Set<String>> ExclusionMap = new HashMap<String, Set<String>>();
		String[] OutputCSV = new String[] { "Coefficient,Label,Offering Service,Year,LabelEx" };
		generateCSV(OutputCSV);

// ------------------------------------------------------------------------------------------------------------------------------------------------------------

		UseCaseMapping.put("12", "MOD01,Modernization,2"); //10 : Codenumber ; MOD01 : Use Case ; Modernization : Service Offer; 0 : Year
		UseCaseMapping.put("22", "MOD02,Modernization,2");
		UseCaseMapping.put("42", "MOD03,Modernization,2");
		//UseCaseMapping.put("81", "MOD04,Modernization,0");
		UseCaseMapping.put("102", "SP01,Service Plan,2");
		UseCaseMapping.put("202", "SP02,Service Plan,2");
		UseCaseMapping.put("402", "SP03,Service Plan,2");
		UseCaseMapping.put("802", "SP04,Service Plan,2");
		UseCaseMapping.put("1602", "SP05,Service Plan,2");
		UseCaseMapping.put("10002", "PM01,Preventive,2");
		UseCaseMapping.put("20002", "MPS01,Consulting,2");
		UseCaseMapping.put("40002", "REV01,Battery Replacement,2");
		UseCaseMapping.put("100002", "EAA01,Ecostructure Asset Advisor,2");
		UseCaseMapping.put("200002", "EAA02,Ecostructure Asset Advisor,2");
		UseCaseMapping.put("400002", "REV02,Part Replacement,2");
		UseCaseMapping.put("800002", "SPARE01,Part Replacement,2");
		
		

		// add exclusion rules for Use Cases

		ExclusionMap.put("SP01", new HashSet<String>(Arrays.asList(new String[] { "MOD01", "MOD02" })));//this means that SP01 is excluded by "MOD01", "MOD02"
		ExclusionMap.put("SP02", new HashSet<String>(Arrays.asList(new String[] { "MOD01", "MOD02" })));
		ExclusionMap.put("SP04", new HashSet<String>(Arrays.asList(new String[] { "MOD01", "MOD02" })));
		ExclusionMap.put("SP05", new HashSet<String>(Arrays.asList(new String[] { "MOD01", "MOD02" })));
		ExclusionMap.put("SP03", new HashSet<String>(Arrays.asList(new String[] { "MOD01", "MOD02", "SP01", "SP02", "SP03", "SP04", "SP05", "PM01", "REV01", "MPS01" })));
		ExclusionMap.put("PM01", new HashSet<String>(Arrays.asList(new String[] { "MOD01", "MOD02", "SP01", "SP02", "SP04", "SP05" }))); //this means that SP01 is excluded by "MOD01", "MOD02", "SP01", "SP02", "SP04", "SP05"
		ExclusionMap.put("REV01", new HashSet<String>(Arrays.asList(new String[] { "MOD01", "MOD02" })));

// ------------------------------------------------------------------------------------------------------------------------------------------------------------

		for (String key : UseCaseMapping.keySet()) {
			UseCaseCodeNumbers.put(Integer.parseInt(key),
					UseCaseMapping.get(key).substring(0, UseCaseMapping.get(key).indexOf(",")));
		}

		Integer[] intarray = new Integer[UseCaseMapping.keySet().size()];
		int numberOfUC = intarray.length;
		int i = 0;
		for (String str : UseCaseMapping.keySet()) {
			intarray[i] = Integer.parseInt(str.trim());
			i++;
		}
		for (int j = 0; j <= numberOfUC; j++) {
			printCombination(intarray, numberOfUC, j, UseCaseMapping, UseCaseCodeNumbers, ExclusionMap);
		}
	}

	static void generateCSV(String[] OutputCSV) {
		String path = "C://Projects/IBGenius/Mar19 Release/MappingIBgeniusV2.csv";
		FileWriter writer;
		try {
			writer = new FileWriter(path, true);
			for (int j = 0; j < OutputCSV.length; j++) {
				writer.write(OutputCSV[j]);
				writer.write("\r\n");
			}
			writer.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
